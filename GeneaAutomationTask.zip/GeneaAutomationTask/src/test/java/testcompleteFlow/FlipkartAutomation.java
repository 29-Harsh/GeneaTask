package testcompleteFlow;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class FlipkartAutomation {
	
    private WebDriver driver;
    private WebDriverWait wait;
	
	 @BeforeClass
	    public void setup() {
	        // Set ChromeDriver path according to your environment
		 	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//driver//chromedriver.exe");
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }
	 
	 @Test
	 public void automationTask() {
	        // Step 1: Open Google and search "Flipkart"
	        driver.get("https://www.google.com");
	        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("q")));
	        searchBox.sendKeys("Flipkart");
	        
	
	// Print all autocomplete suggestions
     List<WebElement> suggestions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("ul.G43f7e li")));
     System.out.println("############### Google Suggestions:##############");
     for (WebElement suggestion : suggestions) {
         System.out.println(suggestion.getText());
     }
	
     searchBox.submit();

     // Print search results
     List<WebElement> searchResults = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("h3")));
     System.out.println("############# Google Search Results: #############");
     for (WebElement result : searchResults) {
         System.out.println(result.getText());
     }

     // Click on the first link
     searchResults.get(0).click();
     
     // Close login popup if present
     try {
         WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("span._30XB9F")));
         closeButton.click();
     } catch (Exception e) {
         System.out.println("Login popup not displayed");
     }
     
     // Step 3: Navigate to Window ACs
     WebElement appliances = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Appliances']")));
     appliances.click();

     WebElement tvAndAppliances = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='TVs & Appliances']")));
     Actions action = new Actions(driver);
     action.moveToElement(tvAndAppliances).perform();

     WebElement windowACs = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Window ACs']")));
     windowACs.click();
     
     // Verify product list
     WebElement isWindowAC = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h1.BUOuZu")));
     assertEquals(isWindowAC.getText(), "Window Air Conditioners");
  

     
     
     List<WebElement> checkboxes = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[text()='Add to Compare']"))); 
     System.out.println(checkboxes.size());
     for (int i = 0; i < checkboxes.size(); i++) {
    	 if(i==2 || i==5 || i==7 || i==8) {
    		checkboxes.get(i).click(); 
    	 }
    	 if(i==9) {
    		 checkboxes.get(i).click();
    		 WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".eIDgeN")));
             System.out.println("Message after adding 9th product: --------> " + message.getText());
    	 }
    		 
		
     }
     
     // Step 4: Add to Compare
//     int[] productIndexes = {2, 5, 7, 8, 9};
//     for (int index : productIndexes) {
//         String checkboxXPath = "(//div[@class='_24_Dny'])[" + index + "]";
//         WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(checkboxXPath)));
//         checkbox.click();
//         if (index == 9) {
//             WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("._3dsJAO")));
//             System.out.println("Message after adding 9th product: " + message.getText());
//         }
//     }
     
     // Step 5: Click on Compare
     WebElement compareButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='COMPARE']")));
     compareButton.click();

     // Step 6: Print product names and prices
     List<WebElement> productNames = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".NKi0M6")));
     List<WebElement> productPrices = driver.findElements(By.cssSelector(".Nx9bqj"));
     System.out.println("############ Compared Products: ############");
     for (int i = 0; i < (productNames.size())/2; i++) {
         System.out.println("Name: " + productNames.get(i).getText() + ", Price: " + productPrices.get(i).getText());
     }

     // Step 7: Add all 4 products to cart
     for (WebElement addToCartButton : driver.findElements(By.xpath("//button[text()='Add to cart']"))) {
         addToCartButton.click();
     }

     // Step 8: Check product pincode delivery availability
     WebElement checkPincode = driver.findElement(By.cssSelector("button.KlGwJl"));
     WebElement enterPincode = driver.findElement(By.xpath("//input[@placeholder='Enter pincode']"));
     enterPincode.sendKeys("452008");
     WebElement submitPincode = driver.findElement(By.xpath("//div[text()='Submit']"));
     
     WebElement deliveryMessage = driver.findElement(By.cssSelector("div.lHfxO4"));
     System.out.println("######### Delivery Message : ############# " + deliveryMessage.getText());
   
	        
	 }
	 
	 @AfterClass
	    public void teardown() {
	        if (driver != null) {
//	            driver.quit();
	        }
	    }
	 
}
